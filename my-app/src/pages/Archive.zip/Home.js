import Home_hero from "../component/Home_hero";
import Navbar from "../component/Navbar";
import Home_explorecard from "../component/Home_explorecard";
import Home_whyus from "../component/Home_whyus";
import Home_testimonials from "../component/Home_testimonials";
import styles from "../style"
import Home_contactus from "../component/Home_contactus";
import Home_weunderstand from "../component/Home_weunderstand";
import Footer from "../component/Footer";
import logo from "../assets/logo.png"
export default function Home() {
    return (
        <>
        <div className="bg-white">
            <div className={`${styles.paddingX} ${styles.flexCenter}`}>
                <div className={`${styles.boxWidth}`}>
                    <Navbar />
                    <Home_hero />
                </div>
            </div>
         
            
        <div className={`mx-auto max-w-[1380px] justify-center items-center ${styles.paddingX} ${styles.flexCenter}`}>
            <div className={`${styles.boxWidth}`}>


            <div className="mt-[100px]">
                <h1 id="explore" className="text-4xl font-bold font-poppins mb-8">Explore</h1>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <Home_explorecard
                    title="Villa Rumah Nyaman"
                    description="Experience luxury and tranquility at Villa Rumah Nyaman, with breathtaking views and exceptional service."
                    price="Rp. 250.000/Night"
                    imageUrl={logo}
                    />
                    <Home_explorecard
                    title="Serenity Bali Resort"
                    description="Experience luxury and tranquility at Serenity Bali Resort, with breathtaking views and exceptional service."
                    price="Rp. 325.000/Night"
                    imageUrl={logo} 
                    />
                    <Home_explorecard
                    title="Hollow Villa Resort"
                    description="Experience luxury and tranquility at Hollow Villa Resort, with breathtaking views and exceptional service."
                    price="Rp. 275.000/Night"
                    imageUrl={logo}
                    />
                </div>
                </div>
     

                <div className="mt-[150px]"> 
                <Home_weunderstand/>
                </div>
           
            

            <Home_whyus />
            
            <Home_testimonials />

            <Home_contactus />

            <Footer />
            </div>
        </div>
        </div>
        </>

        



    )
}